const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client();

client.on('qr', (qr) => {
  console.log('Scan this QR code to log in:');
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('✅ WhatsApp Web is ready!');

  // Change the number and message below 👇
  const number = '97155451483'; // Add country code, no '+' sign
  const message = 'Hello from Node.js using wwebjs! 🚀';

  // Convert to WhatsApp format
  const chatId = `${number}@c.us`;

  client.sendMessage(chatId, message)
    .then(() => console.log('📩 Message sent successfully!'))
    .catch(err => console.error('❌ Failed to send message:', err));
});

client.initialize();
