// main.js
const express = require('express');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs-extra');

const app = express();
const cors = require('cors');

app.use(cors());          // enable CORS for all routes
app.use(express.json());  // parse JSON body

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Persistent sessions directory
const SESSIONS_DIR = './sessions';
fs.ensureDirSync(SESSIONS_DIR);

// Active sessions in memory
const sessions = {};       // { clientId: { client, isReady, qr } }
const activeClientIds = new Set(); // prevent duplicate connections

// Broadcast message to all WS clients
function broadcast(data) {
  wss.clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  });
}

// Create or restore WhatsApp client per clientId
function createClient(clientId) {
  if (sessions[clientId]) return sessions[clientId].client; // already exists

  const client = new Client({
    authStrategy: new LocalAuth({ dataPath: path.join(SESSIONS_DIR, clientId) }),
    puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
  });

  sessions[clientId] = { client, isReady: false, qr: null };

  client.on('qr', async (qr) => {
    sessions[clientId].qr = qr;

    // Convert to data URL
    const qrImage = await qrcode.toDataURL(qr);
    broadcast({ type: 'qr', clientId, qr: qrImage });

    // Optional: force QR refresh every 90 seconds
    if (sessions[clientId].qrTimeout) clearTimeout(sessions[clientId].qrTimeout);
    sessions[clientId].qrTimeout = setTimeout(() => {
      console.log(`QR expired for ${clientId}, requesting new QR...`);
      client.logout();       // reset session
      sessions[clientId].isReady = false;
      sessions[clientId].qr = null;
      client.initialize();   // re-initiate QR
    }, 30000); // 90 sec
  });


  client.on('ready', () => {
    sessions[clientId].isReady = true;
    console.log(`✅ Client ${clientId} ready!`);
    broadcast({ type: 'ready', clientId });
  });

  client.on('disconnected', () => {
    sessions[clientId].isReady = false;
    console.log(`⚠️ Client ${clientId} disconnected.`);
    // Remove from activeClientIds to allow reconnect
    activeClientIds.delete(clientId);
    // Optional: auto-reconnect
    client.initialize();
  });

  client.initialize();
  return client;
}

// Restore all existing sessions on server start
fs.readdirSync(SESSIONS_DIR).forEach(clientId => createClient(clientId));

// REST API to send message
app.post('/send-message', async (req, res) => {
  const { clientId, number, message } = req.body;
  if (!clientId || !number || !message)
    return res.status(400).json({ error: 'clientId, number, and message required' });

  const session = sessions[clientId];
  if (!session) return res.status(404).json({ error: 'Client not found' });
  if (!session.isReady) return res.status(503).json({ error: 'WhatsApp not connected yet' });

  try {
    const chatId = `${number}@c.us`;
    await session.client.sendMessage(chatId, message);
    res.json({ success: true, message: 'Message sent successfully!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Map WebSocket to its clientId
const wsClients = new Map();

wss.on('connection', (ws) => {

  ws.on('message', (msg) => {
    const data = JSON.parse(msg);

    if (data.type === 'connect' && data.clientId) {
      const clientId = data.clientId;

      // Check if this ws already owns the clientId
      if (activeClientIds.has(clientId) && wsClients.get(ws) !== clientId) {
        ws.send(JSON.stringify({ type: 'error', message: 'Client ID already exists!' }));
        return;
      }

      // Mark ws as owner of this clientId
      wsClients.set(ws, clientId);
      activeClientIds.add(clientId); // mark as active

      createClient(clientId);        // create or restore session

      ws.send(JSON.stringify({ type: 'session', clientId }));

      const session = sessions[clientId];
      if (session.isReady) ws.send(JSON.stringify({ type: 'ready', clientId }));
      else if (session.qr) ws.send(JSON.stringify({ type: 'qr', clientId, qr: session.qr }));
    }
  });

  ws.on('close', () => {
    // Remove mapping and free active clientId if needed
    const clientId = wsClients.get(ws);
    if (clientId) {
      wsClients.delete(ws);
      activeClientIds.delete(clientId);
    }
  });

});


// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
